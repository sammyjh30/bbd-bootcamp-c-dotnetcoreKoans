using Xunit;

namespace DotNetCoreKoans.Engine.Tests
{
    public class SensiTests
    {
        [Fact]
        public void TrueShouldBeTrue()
        {
            Assert.True(true);
        }
    }
}